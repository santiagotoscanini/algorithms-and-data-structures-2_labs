
public class Node<T> {
	T data;
	Node<T> next;
	Node<T> pre;

	Node(T d) {
		this.data = d;
	}

	Node(Node<T> p, T d, Node<T> n) {
		this.data = d;
		this.pre = p;
		this.next = n;
	}
}